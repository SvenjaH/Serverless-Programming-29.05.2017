/*
title: resize.js
description: Lambda-Funktion zur Größenänderung eines Bildes
author: Svenja Haberditzl
help from: AWS Tutorial "Using Lambda with Amazon S3 
           (http://docs.aws.amazon.com/lambda/latest/dg/with-s3-example.html)
software: Netbeans 8.2
*/

// benötigte Module werden aus dem ZIP-Ordner der Funktion eingebunden
var async = require('async');
var path = require('path');
var AWS = require('aws-sdk');
var gm = require('gm').subClass({
    imageMagick: true
});
var util = require('util');

// Verbindung zu S3 herstellen
var s3 = new AWS.S3();
// exports.handler wird definiert
exports.handler = function(event, context) {
    // Auslesen aus dem Event
    console.log("Reading options from event:\n", util.inspect(event, {
        depth: 5
    }));
	// Auslesen des Namens des aktuellen Buckets, in den die Originalbilder hochgeladen werden
    var ausgangBucket = event.Records[0].s3.bucket.name;
    // Beseitigung unerwünschter Zeichen
    var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(
        /\+/g, " "));
		// Festlegung des Zielbuckets durch Anhängen einer Endung an den ausgelesen aktuellen Bucket
      var zielBucket = ausgangBucket + "-test";
   // Festelgen der Eigenschaften für das zu verkleinernde Bild
    var _800px = {
        width: 800,
        dstnKey: srcKey,
        destinationPath: "images2"
    };
   
    var _sizesArray = [_800px];
    var len = _sizesArray.length;
  
    // Infer the image type.
    var typeMatch = srcKey.match(/\.([^.]*)$/);
    var fileName = path.basename(srcKey);
    
	// Festlegen der erlaubten Dateitypen für die Anwendung der Funktion
    var imageType = typeMatch[1].toLowerCase();
    if (imageType != "jpg" && imageType != "gif" && imageType != "png" &&
        imageType != "eps") {
        console.log('skipping non-image ' + srcKey);
        return;
    }
	// Umwandlung und speichern vom Ausgangsbucket in den Zielbucket
    async.forEachOf(_sizesArray, function(value, key, callback) {
        async.waterfall([
			// Originaldatei wird runtergeladen zur Umänderung
            function download(next) {
                // Das Bild wird zunächst in einen Buffer geladen, um es dann verändern zu können
                s3.getObject({
                    Bucket: ausgangBucket,
                    Key: srcKey
                }, next);
            },
            function convert(response, next) {
                // Ein Bild des Dateityps eps wird in eine JPG Datei umgewandelt
                gm(response.Body).antialias(true).density(
                    300).toBuffer('JPG', function(err,
                    buffer) {
                    if (err) {
                        next(err);
                    } else {
                        next(null, buffer);
                    }
                });
            },
            function process(response, next) {
				// Das Bild wird aus dem Buffer in den Speicher geleitet
                gm(response).size(function(err, size) {
					// Verhindern, dass das Bild gestreckt und damit unbrauchbar wird
                    var scalingFactor = Math.min(
                        _sizesArray[key].width /
                        size.width, _sizesArray[
                            key].width / size.height
                    );
					// Umänderung der Größe
                    var width = scalingFactor *
                        size.width;
                    var height = scalingFactor *
                        size.height;
                    var index = key;
                    this.resize(width, height).toBuffer(
                        'JPG', function(err,
                            buffer) {
                            if (err) {
                                next(err);
                            } else {
                                next(null,
                                    buffer,
                                    key);
                            }
                        });
                });
            },
			// Funktion zum Hochladen des geänderten Bildes in den Zielbucket
            function upload(data, index, next) {
                // Ordner zum Hochladen wird definiert ebenso wie die DAteiart JPG für jedes veränderte Bild
                s3.putObject({
                    Bucket: zielBucket,
                    Key:  _sizesArray[
                            index].destinationPath +
                        "/" + fileName.slice(0, -4) +
                        ".jpg",
                    Body: data,
                    ContentType: 'JPG'
                }, next);
            }
        ]);
    });
};