/*
title: loginAuth.js
description: Lambda-Funktion zum Aufbau eines Logins
author: Svenja Haberditzl
help from: "Serverless Architectures using AWS Lambda"
           (http://blog.tonyfendall.com/2015/12/serverless-architectures-using-aws-lambda/)
software: Netbeans 8.2
*/

'use strict';

var AmazonCognitoIdentity = require("./amazon-cognito-identity.min.js");
var AuthenticationDetails = AmazonCognitoIdentity.AuthenticationDetails;
var CognitoUser = AmazonCognitoIdentity.CognitoUser;
var CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;

// Daten festlegen für Benutzer, CognitoPools, und Region (wegen Github entfernt)
var mock_event={
    username: 'admin',
    password: '123456',
    app_id: '',
    userpool_id: '',
    identitypool_id: '',
    region: 'eu-central-1'
}

// exports.handler wird definiert
exports.handler = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
	// Variablen für vorher angegebene Nutzerdaten erstellen und Daten an diese übergeben
    var authenticationData = {
        Username: event.username,
        Password: event.password,
    };
    var authenticationDetails = new AuthenticationDetails(authenticationData);

	// Variablen für vorher angegebene Nutzerdaten erstellen und Daten an diese übergeben
    var poolData = {
        UserPoolId: event.userpool_id,
        ClientId: event.app_id
    };
    // Variablen für vorher angegebene Nutzerdaten erstellen und Daten an diese übergeben
    var userPool = new CognitoUserPool(poolData);
    let userData = {
        Username: event.username,
        Pool: userPool
    };

	// Erstellung eines neuen Nutzers im User Pool mit Ausgabe eines Tokens für diesen
    var cognitoUser = new CognitoUser(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
            console.log('AccessToken: ' + result.getAccessToken().getJwtToken());
            console.log('Token: ' + result.getIdToken().getJwtToken());
            console.log(JSON.stringify(result))
            callback && callback(null, JSON.stringify(result));
        },
        onFailure: function (err) {
            console.log("Kein Erfolg-" + err.code + ": " + err.message)
            callback && callback(null, err.message);
        },
    });

	// Bei erfolgreichem Durchlaufen der Funktion erscheint eine Rückmeldung darüber
    console.log("End")
	callback(null, "Erfolgreicher Login);
};

// Daten des mock_event werden eingebunden
exports.handler(mock_event, null, null);